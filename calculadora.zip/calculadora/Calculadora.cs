﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Calculadora
{
    class Valores
    {
        private double valorA;
        private double valorB;
        


        public double VALORa
        {
            get { return valorA; }
            set { valorA = value; }
        }


        public double VALORb
        {
            get { return valorB; }
            set { valorB = value; }
        }
    }
}
